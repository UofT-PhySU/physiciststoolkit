from setuptools import setup, find_packages
import codecs
import os

here = os.path.abspath(os.path.dirname(__file__))

with codecs.open(os.path.join(here, "README.md"), encoding="utf-8") as fh:
    long_description = "\n" + fh.read()

VERSION = '0.0.10'
DESCRIPTION = 'Frequently used functions for physics undergrads.'

# Setting up
setup(
    name="physicist_toolkit",
    version=VERSION,
    author="Shuhan Zheng, and the PhySU Execs",
    author_email="<physu@physics.utoronto.ca>",
    description=DESCRIPTION,
    package_dir={'': 'codes'},
    packages=find_packages(where='codes'),
    long_description_content_type="text/markdown",
    long_description=long_description,
    url="https://github.com/UofT-PhySU/physiciststoolkit",
    license='MIT',
    install_requires=['matplotlib', 'numpy', 'scipy', 'uncertainties', 'multiprocessing'],
    keywords=['python', 'physics', 'data analysis', 'quality of life'],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"],
    python_requires='>=3.10',
)
